from flask import Flask, request, jsonify
import redis, os

app = Flask(__name__)
r = redis.Redis(host=os.environ.get('REDIS_HOST', 'redis-service'), port=6379)

@app.route('/')
def home():
    return jsonify({"message": "Student Result App on Kubernetes!", "status": "running"})

@app.route('/add', methods=['POST'])
def add():
    data = request.json
    r.set(data['name'], data['result'])
    return jsonify({"msg": f"{data['name']} er result save hoyeche!"})

@app.route('/get/<name>')
def get(name):
    result = r.get(name)
    if result:
        return jsonify({"name": name, "result": result.decode()})
    return jsonify({"msg": "Pawa jay ni"}), 404

@app.route('/health')
def health():
    return jsonify({"status": "healthy"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
